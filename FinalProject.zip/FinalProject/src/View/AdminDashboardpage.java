/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Mohammed
 */
public class AdminDashboardpage extends Stage {

    private Scene PatientsMangment;
    private Scene createnewpatient;
    private Scene updatepatient;
    private Scene appointmentsMangment;
    private Scene createappointment;
    private Scene updateappointment;
    
    
    
    public AdminDashboardpage() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Fxml/PatientsMangment.fxml"));
        Parent PatientsMangmentroot = fxmlLoader.load();
        PatientsMangment = new Scene(PatientsMangmentroot);

        FXMLLoader createpatientLoader = new FXMLLoader(getClass().getResource("FXML/createnewpatient.fxml"));
        Parent createnewpatientroot = createpatientLoader.load();
        createnewpatient = new Scene(createnewpatientroot);

//        FXMLLoader updatepatientLoader = new FXMLLoader(getClass().getResource("FXML/updatepatient.fxml"));
//        Parent updatepatientroot = updatepatientLoader.load();
//        updatepatient = new Scene(updatepatientroot);

        FXMLLoader appointmentsMangmentLoader = new FXMLLoader(getClass().getResource("FXML/appointmentsMangment.fxml"));
        Parent appointmentsMangmentroot = appointmentsMangmentLoader.load();
        appointmentsMangment = new Scene(appointmentsMangmentroot);

        FXMLLoader createappointmentLoader = new FXMLLoader(getClass().getResource("FXML/createappointment.fxml"));
        Parent createappointmentroot = createappointmentLoader.load();
        createappointment = new Scene(createappointmentroot);
        
        
//        FXMLLoader updateappointmentLoader = new FXMLLoader(getClass().getResource("FXML/updateappointment.fxml"));
//        Parent updateappointmentroot = updateappointmentLoader.load();
//        updateappointment = new Scene(updateappointmentroot);

        this.setScene(PatientsMangment);
        this.setTitle("Admin Dashboard page");

    }

    public void changeSceneToPatientsMangment() {
        this.setScene(PatientsMangment);
    }
    
    
//     public void changeSceneToupdateappointment() {
//        this.setScene(updateappointment);
//    }

    public void changeSceneToCreatePatient() {
        this.setScene(createnewpatient);
    }

//    public void changeSceneToupdatepatient() {
//        this.setScene(updatepatient);
//    }

    public void changeSceneToappointmentsMangment() {
        this.setScene(appointmentsMangment);
    }
    
    
    
    public void changeSceneTocreateappointment() {
        this.setScene(createappointment);
    }


}
