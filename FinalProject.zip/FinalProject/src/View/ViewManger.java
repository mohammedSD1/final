/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.io.IOException;

/**
 *
 * @author Mohammed
 */
public class ViewManger {

    public static PatientLoginpage PatientLoginpage;
    public static PatientRegisterpage PatientRegisterpage;
    public static PatientDashboardpage PatientDashboardpage;
    public static AdminLoginpage AdminLoginpage;
    public static AdminDashboardpage AdminDashboardpage;

    private ViewManger() {

    }
    
    public static void openPatientLoginpage() throws IOException {
        if (PatientLoginpage == null) {
            PatientLoginpage = new PatientLoginpage();
            PatientLoginpage.show();
        } else {
            PatientLoginpage.show();
        }
    }

    public static void openPatientRegisterpage() throws IOException {
        if (PatientRegisterpage == null) {
            PatientRegisterpage = new PatientRegisterpage();
            PatientRegisterpage.show();
        } else {
            PatientRegisterpage.show();
        }
    }

    public static void openPatientDashboardpage() throws IOException {
        if (PatientDashboardpage == null) {
            PatientDashboardpage = new PatientDashboardpage();
            PatientDashboardpage.show();
        } else {
            PatientDashboardpage.show();
        }
    }

    public static void openAdminLoginpage() throws IOException {
        if (AdminLoginpage == null) {
            AdminLoginpage = new AdminLoginpage();
            AdminLoginpage.show();
        } else {
            AdminLoginpage.show();
        }
    }

    public static void openAdminDashboardpage() throws IOException {
        if (AdminDashboardpage == null) {
            AdminDashboardpage = new AdminDashboardpage();
            AdminDashboardpage.show();
        } else {
            AdminDashboardpage.show();
        }
    }

    public static void closePatientLoginpage() throws IOException {
        if (PatientLoginpage != null) {
            PatientLoginpage.close();
        }

    }

    public static void closePatientRegisterpage() throws IOException {
        if (PatientRegisterpage != null) {
            PatientRegisterpage.close();
        }

    }

    public static void closePatientDashboardpage() throws IOException {
        if (PatientDashboardpage != null) {
            PatientDashboardpage.close();
        }

    }

    public static void closeAdminLoginpage() throws IOException {
        if (AdminLoginpage != null) {
            AdminLoginpage.close();
        }

    }

    public static void closeAdminDashboardpage() throws IOException {
        if (AdminDashboardpage != null) {
            AdminDashboardpage.close();
        }
    }

}
