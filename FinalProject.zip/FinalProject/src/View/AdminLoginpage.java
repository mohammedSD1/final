/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Mohammed
 */
public class AdminLoginpage extends Stage{
      public AdminLoginpage() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Fxml/AdminLogin.fxml"));
        Parent patrent = fxmlLoader.load();
        Scene scene = new Scene(patrent);
        setScene(scene);
        setTitle("Admin Login page");
    }
}
