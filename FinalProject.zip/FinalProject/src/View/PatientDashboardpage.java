/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Mohammed
 */
public class PatientDashboardpage extends Stage {

    private Scene PatientDashboardpage;
    private Scene allbooked;

    public PatientDashboardpage() throws IOException {
        FXMLLoader PatientDashboardpageLoader = new FXMLLoader(getClass().getResource("Fxml/PatientDashboardpage.fxml"));
        Parent PatientDashboardpageroot = PatientDashboardpageLoader.load();
        PatientDashboardpage = new Scene(PatientDashboardpageroot);

        FXMLLoader allbookedLoader = new FXMLLoader(getClass().getResource("Fxml/allbooked.fxml"));
        Parent Pallbookedroot = allbookedLoader.load();
        allbooked = new Scene(Pallbookedroot);

        this.setScene(PatientDashboardpage);
        this.setTitle("Patient Dashboard page");

    }

    public void changeSceneToPatientDashboardpage() {
        this.setScene(PatientDashboardpage);
    }

    public void changeSceneToallbooked() {
        this.setScene(allbooked);
    }

}
