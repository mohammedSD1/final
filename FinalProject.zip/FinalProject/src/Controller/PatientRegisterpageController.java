/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.users;
import View.ViewManger;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class PatientRegisterpageController implements Initializable {

    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField age;
    @FXML
    private TextField email;
    @FXML
    private TextField phone;
    @FXML
    private ToggleGroup genderGroup;
    @FXML
    private ToggleGroup roleGroup;

   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void register(ActionEvent event) throws SQLException, ClassNotFoundException, IOException {
        String username = this.username.getText();
        String password = this.password.getText();
        String firsname = this.firstname.getText();
        String lastname = this.lastname.getText();
        String age = this.age.getText();
        String email = this.email.getText();
        String phone = this.phone.getText();
        String gender = ((RadioButton) genderGroup.getSelectedToggle()).getText();
        String role = ((RadioButton) roleGroup.getSelectedToggle()).getText();
        // make an user object having this data
        users user = new users(username, password, firsname, lastname, age, email, phone, gender, role);
        // save the user in database by save method
        user.save();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("patient inserted");
        alert.setContentText("patient inserted");
        alert.showAndWait();
        ViewManger.closePatientRegisterpage();
        ViewManger.openPatientLoginpage();

    }

    @FXML
    private void cancel(ActionEvent event) throws IOException {
        ViewManger.closePatientRegisterpage();
        ViewManger.openPatientLoginpage();
    }

}
