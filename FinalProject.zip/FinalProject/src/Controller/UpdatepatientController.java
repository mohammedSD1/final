/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.users;
import View.ViewManger;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class UpdatepatientController implements Initializable {

  
    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField age;
    @FXML
    private TextField email;
    @FXML
    private TextField phone;
    @FXML
    private ToggleGroup genderGroup;
    @FXML
    private ToggleGroup roleGroup;

    private users oldpatient;
    @FXML
    private RadioButton famale;
    @FXML
    private RadioButton male;
    @FXML
    private RadioButton admin;
    @FXML
    private RadioButton patient;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.oldpatient = View.Fxml.PatientsMangmentController.selectedpatientToUpdate;
        username.setText(oldpatient.getUsername());
        password.setText(oldpatient.getPassword());
        firstname.setText(oldpatient.getFirstname());
        lastname.setText(oldpatient.getLastname());
        age.setText(oldpatient.getAge());
        email.setText(oldpatient.getEmail());
        phone.setText(oldpatient.getPhone());
        
        if (oldpatient.getGender().equals("female")) {
            genderGroup.selectToggle(famale);
        }
        if (oldpatient.getRole().equals("admin")) {
            roleGroup.selectToggle(admin);
        }
    }

    @FXML
    private void seenpatients(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToPatientsMangment();
    }

    @FXML
    private void seenappointments(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

    @FXML
    private void update(ActionEvent event) throws SQLException, ClassNotFoundException {
        String username = this.username.getText();
        String password = this.password.getText();
        String firsname = this.firstname.getText();
        String lastname = this.lastname.getText();
        String age = this.age.getText();
        String email = this.email.getText();
        String phone = this.phone.getText();
        String gender = ((RadioButton) genderGroup.getSelectedToggle()).getText();
        String role = ((RadioButton) roleGroup.getSelectedToggle()).getText();
        users patient = new users(username, password, firsname, lastname, age, email, phone, gender, role);
        patient.setId(oldpatient.getId());
        patient.update();
        View.Fxml.PatientsMangmentController.updateStage.close();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("patient updated");
        alert.setContentText("patient updated");
        alert.showAndWait();
    }

    @FXML
    private void cancel(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToPatientsMangment();
    }

    @FXML
    private void show(ActionEvent event) {
        this.oldpatient = View.Fxml.PatientsMangmentController.selectedpatientToUpdate;
        username.setText(oldpatient.getUsername());
        password.setText(oldpatient.getPassword());
        firstname.setText(oldpatient.getFirstname());
        lastname.setText(oldpatient.getLastname());
        age.setText(oldpatient.getAge());
        email.setText(oldpatient.getEmail());
        phone.setText(oldpatient.getPhone());

        if (oldpatient.getGender().equals("female")) {
            genderGroup.selectToggle(famale);
        }

        if (oldpatient.getRole().equals("admin")) {
            roleGroup.selectToggle(admin);
        }
    }

}
