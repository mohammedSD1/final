/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.Appointments;
import View.ViewManger;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class PatientDashboardpageController implements Initializable {

    @FXML
    private TableView<Appointments> appointmentTableView;
    @FXML
    private TableColumn<Appointments, Integer> id;
    @FXML
    private TableColumn<Appointments, String> date;
    @FXML
    private TableColumn<Appointments, String> day;
    @FXML
    private TableColumn<Appointments, String> time;
    @FXML
    private TableColumn<Appointments, String> status;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        id.setCellValueFactory(new PropertyValueFactory("id"));
        date.setCellValueFactory(new PropertyValueFactory("appointment_date"));
        day.setCellValueFactory(new PropertyValueFactory("appointment_day"));
        time.setCellValueFactory(new PropertyValueFactory("appointment_time"));
        status.setCellValueFactory(new PropertyValueFactory("status"));
    }

    @FXML
    private void seenmangmentappoinments(ActionEvent event) {
        ViewManger.PatientDashboardpage.changeSceneToPatientDashboardpage();
    }

    @FXML
    private void doctorcomment(ActionEvent event) {

    }

    @FXML
    private void showfree(ActionEvent event) throws SQLException, ClassNotFoundException {
        ObservableList<Appointments> AppointmentsList
                = FXCollections.observableArrayList(Appointments.getAllfreeappointments());
        appointmentTableView.setItems(AppointmentsList);
    }

    @FXML
    private void bookfreeappointment(ActionEvent event) {
        
    }

    @FXML
    private void showbooked(ActionEvent event) {
       ViewManger.PatientDashboardpage.changeSceneToallbooked();
    }

    @FXML
    private void logout(ActionEvent event) throws IOException {
        ViewManger.closePatientDashboardpage();
    }

}
