/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.Appointments;
import View.ViewManger;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class CreateappointmentController implements Initializable {

    @FXML
    private ToggleGroup statusGroup;
    @FXML
    private TextField date;
    @FXML
    private TextField day;
    @FXML
    private TextField time;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void seenpatients(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToPatientsMangment();
    }

    @FXML
    private void seenappointments(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

    @FXML
    private void register(ActionEvent event) throws SQLException, ClassNotFoundException {
        String date = this.date.getText();
        String day = this.day.getText();
        String time = this.time.getText();
        String status = ((RadioButton) statusGroup.getSelectedToggle()).getText();
        Appointments Appointment=new Appointments(date,day,time,status);
        Appointment.save();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Appointment inserted");
        alert.setContentText("Appointment inserted");
        alert.showAndWait();
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

    @FXML
    private void cancel(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

}
