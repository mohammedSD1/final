/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.Appointments;
import Model.db;
import View.ViewManger;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class AllbookedController implements Initializable {

    @FXML
    private TableView<Appointments> appointmentTableView;
    @FXML
    private TableColumn<Appointments, Integer> id;
    @FXML
    private TableColumn<Appointments, String> date;
    @FXML
    private TableColumn<Appointments, String> day;
    @FXML
    private TableColumn<Appointments, String> time;
    @FXML
    private TableColumn<Appointments, String> status;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        id.setCellValueFactory(new PropertyValueFactory("id"));
        date.setCellValueFactory(new PropertyValueFactory("appointment_date"));
        day.setCellValueFactory(new PropertyValueFactory("appointment_day"));
        time.setCellValueFactory(new PropertyValueFactory("appointment_time"));
        status.setCellValueFactory(new PropertyValueFactory("status"));
    }

    @FXML
    private void seenmangmentappoinments(ActionEvent event) {
        ViewManger.PatientDashboardpage.changeSceneToPatientDashboardpage();
    }

    @FXML
    private void doctorcomment(ActionEvent event) {

    }

    @FXML
    private void bookedfinished(ActionEvent event) throws SQLException, ClassNotFoundException {
        Connection c = db.getInstanct().getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Appointments> Appointments = new ArrayList<>();

        String sql = "SELECT booked_appointments.id , appointments.appointment_date , appointments.appointment_day, appointments.appointment_time  , booked_appointments.status FROM  booked_appointments , appointments\n"
                + "WHERE appointments.id = booked_appointments.id && booked_appointments.status= \"waiting\";";
        ps = c.prepareStatement(sql);
        rs = ps.executeQuery();
        while (rs.next()) {
            Appointments Appointment = new Appointments(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            Appointment.setId(rs.getInt(1));
            Appointments.add(Appointment);
        }
        if (ps != null) {
            ps.close();
        }
        c.close();
    }

    @FXML
    private void bookedwaiting(ActionEvent event) {

    }

}
