/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.db;
import Model.users;
import View.ViewManger;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class PatientsMangmentController implements Initializable {

    public static users selectedpatientToUpdate;
    public static Stage updateStage;
    
    
    @FXML
    private TextField search;
    @FXML
    private TableView<users> patientTableView;
    @FXML
    private TableColumn<users, Integer> id;
    @FXML
    private TableColumn<users, String> firstname;
    @FXML
    private TableColumn<users, String> lastname;
    @FXML
    private TableColumn<users, String> age;
    @FXML
    private TableColumn<users, String> email;
    @FXML
    private TableColumn<users, String> phone;
    @FXML
    private TableColumn<users, String> gender;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        id.setCellValueFactory(new PropertyValueFactory("id"));
        firstname.setCellValueFactory(new PropertyValueFactory("firstname"));
        lastname.setCellValueFactory(new PropertyValueFactory("lastname"));
        age.setCellValueFactory(new PropertyValueFactory("age"));
        email.setCellValueFactory(new PropertyValueFactory("email"));
        phone.setCellValueFactory(new PropertyValueFactory("phone"));
        gender.setCellValueFactory(new PropertyValueFactory("gender"));
    }

    @FXML
    private void seenpatients(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToPatientsMangment();
    }

    @FXML
    private void seenappointments(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

    @FXML
    private void createpatient(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToCreatePatient();
    }

    @FXML
    private void updatepatient(ActionEvent event) throws IOException{
         if (patientTableView.getSelectionModel().getSelectedItem() != null) {
            //store the selected user from the TableView in our global var user selectedUserToUpdate   
            selectedpatientToUpdate = patientTableView.getSelectionModel().getSelectedItem();
            //load update page fxml
            FXMLLoader loaderUpdate = new FXMLLoader(getClass().getResource("/View/FXML/updatepatient.fxml"));
            Parent rootUpdate = loaderUpdate.load();
            Scene updatepatientScene = new Scene(rootUpdate);
            //store loaded fxml in our global stage updateStage and show it
            updateStage = new Stage();
            updateStage.setScene(updatepatientScene);
            updateStage.setTitle("Update patient " + selectedpatientToUpdate.getId());
            updateStage.show();
        } else {
            Alert warnAlert = new Alert(Alert.AlertType.WARNING);
            warnAlert.setTitle("Select an patient");
            warnAlert.setContentText("Please select an patient from the table view");
            warnAlert.show();
        }

    }

    @FXML
    private void deletepatient(ActionEvent event) {
        if (patientTableView.getSelectionModel().getSelectedItem() != null) {
            //store the selected user from the TableView in new user object
            users selectedpatient = patientTableView.getSelectionModel().getSelectedItem();

            //show an confirmation alert and make the deletion on confirm event
            Alert deleteConfirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
            deleteConfirmAlert.setTitle("patient delete");
            deleteConfirmAlert.setContentText("Are you sure to delete this patient ?");
            deleteConfirmAlert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    try {
                        selectedpatient.delete();
                    } catch (SQLException ex) {
                        Logger.getLogger(PatientsMangmentController.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PatientsMangmentController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    Alert deletedSuccessAlert = new Alert(Alert.AlertType.INFORMATION);
                    deletedSuccessAlert.setTitle("patient deleted");
                    deletedSuccessAlert.setContentText("patient deleted");
                    deletedSuccessAlert.show();
                }
            });
        } else {
            Alert warnAlert = new Alert(Alert.AlertType.WARNING);
            warnAlert.setTitle("Select an patient");
            warnAlert.setContentText("Please select an patient from the table view");
            warnAlert.show();
        }
    }

    @FXML
    private void showpatients(ActionEvent event) throws SQLException, ClassNotFoundException {
        ObservableList<users> usersList
                = FXCollections.observableArrayList(users.getAllpatient());
        patientTableView.setItems(usersList);
    }

    @FXML
    private void searchbutton(ActionEvent event) throws SQLException, ClassNotFoundException {
        patientTableView.getItems().clear();
        String firstname = search.getText();
        Connection c = db.getInstanct().getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM `users` WHERE `role`='patient'";
        ps = c.prepareStatement(sql);
        rs = ps.executeQuery();
        ArrayList<users> userslist = new ArrayList<>();
        while (rs.next()) {
            if (rs.getString(4).equalsIgnoreCase(firstname)){
                users user = new users(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                user.setId(rs.getInt(1));
                userslist.add(user);
                ObservableList<users> usersList
                        = FXCollections.observableArrayList(userslist);
                patientTableView.setItems(usersList);
            }
        }

    }

    @FXML
    private void logout(ActionEvent event) throws IOException {
        ViewManger.closeAdminDashboardpage();
    }

}
