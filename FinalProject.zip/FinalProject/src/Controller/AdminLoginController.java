/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.db;
import View.ViewManger;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class AdminLoginController implements Initializable {

    @FXML
    private Label user;
    @FXML
    private TextField username;
    @FXML
    private Label pass;
    @FXML
    private PasswordField passward;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void Login(ActionEvent event) throws ClassNotFoundException, SQLException, IOException {
        String username = this.username.getText();
        String password = this.passward.getText();
        Connection c = db.getInstanct().getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM `users` WHERE `role`='admin'";
        ps = c.prepareStatement(sql);
        rs = ps.executeQuery();
        if (rs != null) {
            while (rs.next()) {
                if (rs.getString(2).equalsIgnoreCase(username) && rs.getString(3).equalsIgnoreCase(password)) {
                    ViewManger.openAdminDashboardpage();
                    ViewManger.closeAdminLoginpage();
                    break;
                }
            }
        } else {
            System.out.println("not data");
        }
    }

}
