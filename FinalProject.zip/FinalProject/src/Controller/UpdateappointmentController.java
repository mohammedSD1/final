/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Fxml;

import Model.Appointments;
import View.ViewManger;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class UpdateappointmentController implements Initializable {

    private Appointments oldAppointment;
    @FXML
    private TextField date;
    @FXML
    private TextField day;
    @FXML
    private TextField time;
    @FXML
    private ToggleGroup statusGroup;
    @FXML
    private RadioButton booked;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.oldAppointment=View.Fxml.AppointmentsMangmentController.selectedAppointmentToUpdate;
        date.setText(oldAppointment.getAppointment_date());
        day.setText(oldAppointment.getAppointment_day());
        time.setText(oldAppointment.getAppointment_time());
        if (oldAppointment.getStatus().equals("free")) {
            statusGroup.selectToggle(booked);
        }
    }

    @FXML
    private void seenpatients(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToPatientsMangment();
    }

    @FXML
    private void seenappointments(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

    @FXML
    private void Update(ActionEvent event) throws ClassNotFoundException, SQLException {
        String date = this.date.getText();
        String day = this.day.getText();
        String time = this.time.getText();
        String status = ((RadioButton) statusGroup.getSelectedToggle()).getText();
        Appointments Appointment = new Appointments(date, day, time, status);
        Appointment.setId(oldAppointment.getId());
        Appointment.update();
        View.Fxml.AppointmentsMangmentController.updateStage.close();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Appointment updated");
        alert.setContentText("Appointment updated");
        alert.showAndWait();
    }

    @FXML
    private void cancel(ActionEvent event) {
        ViewManger.AdminDashboardpage.changeSceneToappointmentsMangment();
    }

}
