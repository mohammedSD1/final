/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Mohammed
 */
public class booked_appointments {
   private int id;
   private int appointment_id;
   private int user_id;
   private String status;
   private String doctor_commnet;

    public booked_appointments(int id, int appointment_id, int user_id, String status, String doctor_commnet) {
        this.id = id;
        this.appointment_id = appointment_id;
        this.user_id = user_id;
        this.status = status;
        this.doctor_commnet = doctor_commnet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAppointment_id() {
        return appointment_id;
    }

    public void setAppointment_id(int appointment_id) {
        this.appointment_id = appointment_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDoctor_commnet() {
        return doctor_commnet;
    }

    public void setDoctor_commnet(String doctor_commnet) {
        this.doctor_commnet = doctor_commnet;
    }

    @Override
    public String toString() {
        return "booked_appointments{" + "id=" + id + ", appointment_id=" + appointment_id + ", user_id=" + user_id + ", status=" + status + ", doctor_commnet=" + doctor_commnet + '}';
    }
            		
//     public static ArrayList<Appointments> getAllbookedwaiting() throws SQLException, ClassNotFoundException {
//        Connection c = db.getInstanct().getConnection();
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        ArrayList<users> users = new ArrayList<>();
//        String sql = "SELECT * FROM `users` WHERE `role`='patient'";
//        ps = c.prepareStatement(sql);
//        rs = ps.executeQuery();
//        while (rs.next()) {
//            users user = new users(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6),
//                    rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
//            user.setId(rs.getInt(1));
//            users.add(user);
//        }
//        if (ps != null) {
//            ps.close();
//        }
//        c.close();
//        return users;
//    }
//    
     
    

}
